﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enders.CS.Model
{
    public class NoteModel
    {
        string _nomNote;
        string _descriptionNote;


        public string NomNote 
        { 
            get { return _nomNote;}
            
            set { _nomNote = value; }
        }

        public string DescriptionNote
        { 
            get { return _descriptionNote;}

            set { _descriptionNote = value; }
        }

    }
}
