﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enders.CS.Model
{
    public class InventaireModel
    {
        string _nomInventaire;
        string _descriptionInventaire;


        public string NomInventaire
        {
            get { return _nomInventaire; }

            set { _nomInventaire = value; }
        }

        public string DescriptionInventaire
        {
            get { return _descriptionInventaire; }

            set { _descriptionInventaire = value; }
        }
    }
}
