﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enders.CS.Model
{
    public class EquipementModel
    {
        string _nomEquipement;
        string _descriptionEquipement;

        public string NomEquipement
        {
            get { return _nomEquipement; }
            set { _nomEquipement = value; }
        }

        public string DescriptionEquipement
        {
            get { return _descriptionEquipement; }
            set { _descriptionEquipement = value;}
        }

    }
}
