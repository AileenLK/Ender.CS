﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enders.CS.Model
{
    public class ActifModel
    {
        private string _nomActif;
        private string _descriptionActif;

        public string NomActif
        {
            get { return _nomActif; }

            set { _nomActif = value; }
        }

        public string DescriptionActif
        {
            get { return _descriptionActif; }

            set { _descriptionActif = value; }
        }
    }
}
