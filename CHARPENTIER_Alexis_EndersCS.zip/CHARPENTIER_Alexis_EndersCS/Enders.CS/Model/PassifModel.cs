﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enders.CS.Model
{
    public class PassifModel
    {
        string _nomPassif;
        string _descriptionPassif;

        public string NomPassif
        {
            get { return _nomPassif; }

            set { _nomPassif = value; }
        }

        public string DescriptionPassif
        {
            get { return _descriptionPassif; }

            set { _descriptionPassif = value; }
        }
    }
}
