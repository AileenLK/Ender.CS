﻿using Enders.CS.AddSimpleSystem;
using Enders.CS.Model;
using Enders.CS.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Enders.CS.View
{
    /// <summary>
    /// Logique d'interaction pour CreateWindow.xaml
    /// </summary>
    public partial class CreateWindow : Window
    {
        public CreateWindow()
        {
            InitializeComponent();
            Uri iconUri = new Uri("../Ender.ico", UriKind.RelativeOrAbsolute);
            this.Icon = BitmapFrame.Create(iconUri);
            viewModel = new CreateViewModel();
        }
        CreateViewModel viewModel;
        private void OnlyNumber(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            viewModel.ProfileNameVM = ProfileName.Text;
            viewModel.ProfileLevelVM = ProfileLevel.Text;
            viewModel.ProfileRaceVM = ProfileRace.Text;
            viewModel.ProfileElementVM = ProfileElement.Text;
            viewModel.ProfileClasseVM = ProfileClasse.Text;
            viewModel.ProfileGenreVM = ProfileGenre.Text;
            viewModel.ProfileAgeVM = ProfileAge.Text;
            viewModel.ProfileTailleVM = ProfileTaille.Text;
            viewModel.ProfilePoidsVM = ProfilePoids.Text;
            viewModel.ProfileCheveuxVM = ProfileCheveux.Text;
            viewModel.ProfilePeauVM = ProfilePeau.Text;
            viewModel.ProfileOrientationVM = ProfileOrientation.Text;
            
            viewModel.StatistiquePVVM = PV.Text;
            viewModel.StatistiqueSTRVM = Force.Text;
            viewModel.StatistiqueINTVM = Intelligence.Text;
            viewModel.StatistiqueCHAVM = Charisme.Text;


            //Equipement
            for (int i = 0; i < ListEquipement.Items.Count; i++)
            {
                var equipement = ListEquipement.Items[i] as EquipementModel;
                if(equipement != null)
                {
                    EquipementModel newEquipement = new EquipementModel();
                    newEquipement.NomEquipement = equipement.NomEquipement;
                    newEquipement.DescriptionEquipement = equipement.DescriptionEquipement;
                    viewModel.Equipements.Add(newEquipement);
                }
            }


            //Passif
            for (int i = 0; i < ListPassif.Items.Count; i++)
            {
                var passif = ListPassif.Items[i] as PassifModel;
                if (passif != null)
                {
                    PassifModel newpassif = new PassifModel();
                    newpassif.NomPassif = passif.NomPassif;
                    newpassif.DescriptionPassif = passif.DescriptionPassif;
                    viewModel.Passifs.Add(newpassif);
                }
            }


            //Actif
            for (int i = 0; i < ListActif.Items.Count; i++)
            {
                var actif = ListActif.Items[i] as ActifModel;
                if (actif != null)
                {
                    ActifModel newActif = new ActifModel();
                    newActif.NomActif = actif.NomActif;
                    newActif.DescriptionActif = actif.DescriptionActif;
                    viewModel.Actifs.Add(newActif);
                }
            }

            //Inventaire
            for (int i = 0; i < ListInventaire.Items.Count; i++)
            {
                var inventaire = ListInventaire.Items[i] as InventaireModel;
                if (inventaire != null)
                {
                    InventaireModel newInventaire = new InventaireModel();
                    newInventaire.NomInventaire = inventaire.NomInventaire;
                    newInventaire.DescriptionInventaire = inventaire.DescriptionInventaire;
                    viewModel.Inventaires.Add(newInventaire);
                }
            }

            //Note
            for (int i = 0; i < ListNote.Items.Count; i++)
            {
                var note = ListNote.Items[i] as NoteModel;
                if (note != null)
                {
                    NoteModel newNote = new NoteModel();
                    newNote.NomNote = note.NomNote;
                    newNote.DescriptionNote = note.DescriptionNote;
                    viewModel.Notes.Add(newNote);
                }
            }


            viewModel.SaveAllFiles(viewModel);

        }
    }
}
