﻿using Enders.CS.AddSimpleSystem;
using Enders.CS.Icommand;
using Enders.CS.Model;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace Enders.CS.ViewModel
{
    public class CreateViewModel : ObservableObject
    {


        #region Constructor
        public CreateViewModel()
        {
            for (int i = 0; i < 4; i++)
            {
                //_notes.Add(new NoteModel { NomNote = "Gravier", DescriptionNote = "Délicieux" });
                //_inventaires.Add(new InventaireModel { NomInventaire = "Poele", DescriptionInventaire = "Dure" });
                //_actifs.Add(new ActifModel { NomActif = "Boule de feu", DescriptionActif = "Genere un S.R.U.O.U.R.S" });
                //_passifs.Add(new PassifModel { NomPassif = "Esprit du poisson rouge ancestrale", DescriptionPassif = "une fois par assaut, ne fais rien" });
                //_equipements.Add(new EquipementModel { NomEquipement = "Caleçon en mythril", DescriptionEquipement = "pour un nain Brillant" });
            }


        }

        public string FullSavePath { get; set; } = @"\Enders.CS\Saves\Save";

        string _profileName;
        string _profileLevel;
        string _profileRace;
        string _profileElement;
        string _profileClasse;
        string _profileGenre;
        string _profileAge;
        string _profileTaille;
        string _profilePoids;
        string _profileCheveux;
        string _profilePeau;
        string _profileOrientation;

        string _statistiquePV;
        string _statistiqueSTR;
        string _statistiqueINT;
        string _statistiqueCHA;

        public string ProfileNameVM { get => _profileName; set => _profileName = value; }
        public string ProfileLevelVM { get => _profileLevel; set => _profileLevel = value; }
        public string ProfileRaceVM { get => _profileRace; set => _profileRace = value; }
        public string ProfileElementVM { get => _profileElement; set => _profileElement = value; }
        public string ProfileClasseVM { get => _profileClasse; set => _profileClasse = value; }
        public string ProfileGenreVM { get => _profileGenre; set => _profileGenre = value; }
        public string ProfileAgeVM { get => _profileAge; set => _profileAge = value; }
        public string ProfileTailleVM { get => _profileTaille; set => _profileTaille = value; }
        public string ProfilePoidsVM { get => _profilePoids; set => _profilePoids = value; }
        public string ProfileCheveuxVM { get => _profileCheveux; set => _profileCheveux = value; }
        public string ProfilePeauVM { get => _profilePeau; set => _profilePeau = value; }
        public string ProfileOrientationVM { get => _profileOrientation; set => _profileOrientation = value; }
        public string StatistiquePVVM { get => _statistiquePV; set => _statistiquePV = value; }
        public string StatistiqueSTRVM { get => _statistiqueSTR; set => _statistiqueSTR = value; }
        public string StatistiqueINTVM { get => _statistiqueINT; set => _statistiqueINT = value; }
        public string StatistiqueCHAVM { get => _statistiqueCHA; set => _statistiqueCHA = value; }


        #endregion

        #region Members

        NoteModel Note = new NoteModel();
        ObservableCollection<NoteModel> _notes = new ObservableCollection<NoteModel>();

        InventaireModel Inventaire = new InventaireModel();
        ObservableCollection<InventaireModel> _inventaires = new ObservableCollection<InventaireModel>();


        ActifModel Actif = new ActifModel();
        ObservableCollection<ActifModel> _actifs = new ObservableCollection<ActifModel>();
       
        PassifModel Passif = new PassifModel();
        ObservableCollection<PassifModel> _passifs = new ObservableCollection<PassifModel>();
        
        EquipementModel Equipement = new EquipementModel();
        ObservableCollection<EquipementModel> _equipements = new ObservableCollection<EquipementModel>();


        #endregion


        #region Properties


        /// <summary>
        /// NOTES
        /// </summary>
        
        public ObservableCollection<NoteModel> Notes
        {
            get { return _notes; }
            
            set { _notes = value; }
        }

        public string NomNoteVM
        {
            get {
                if(Note.NomNote != null)
                {
                    return Note.NomNote;
                }
                else
                {
                    return "nom note";
                }

            }

            set
            {
                if (Note.NomNote != value)
                {
                    Note.NomNote = value;
                    RaisePropertyChanged("NomNote");
                }
            }
        }

        public string DescriptionNoteVM
        {
            get
            {
                if (Note.DescriptionNote != null)
                {
                    return Note.DescriptionNote;
                }
                else
                {
                    return "description note";
                }
            }

            set
            {
                if (Note.DescriptionNote != value)
                {
                    Note.DescriptionNote = value;
                    RaisePropertyChanged("DescriptionNote");
                }
            }
        }


        /// <summary>
        /// INVENTAIRE
        /// </summary>

        public ObservableCollection<InventaireModel> Inventaires
        {
            get { return _inventaires; }

            set { _inventaires = value; }
        }

        public string NomInventaireVM
        {
            get
            {
                if (Inventaire.NomInventaire != null)
                {
                    return Inventaire.NomInventaire;
                }
                else
                {
                    return "nom inventaire";
                }

            }

            set
            {
                if (Inventaire.NomInventaire != value)
                {
                    Inventaire.NomInventaire = value;
                    RaisePropertyChanged("NomInventaire");
                }
            }
        }

        public string DescriptionInventaireVM
        {
            get
            {
                if (Inventaire.DescriptionInventaire != null)
                {
                    return Inventaire.DescriptionInventaire;
                }
                else
                {
                    return "description inventaire";
                }
            }

            set
            {
                if (Inventaire.DescriptionInventaire != value)
                {
                    Inventaire.DescriptionInventaire = value;
                    RaisePropertyChanged("DescriptionInventaire");
                }
            }
        }

        /// <summary>
        /// ACTIF
        /// </summary>

        public ObservableCollection<ActifModel> Actifs
        {
            get { return _actifs; }

            set { _actifs = value; }
        }

        public string NomActifVM
        {
            get
            {
                if (Actif.NomActif != null)
                {
                    return Actif.NomActif;
                }
                else
                {
                    return "nom actif";
                }

            }

            set
            {
                if (Actif.NomActif != value)
                {
                    Actif.NomActif = value;
                    RaisePropertyChanged("NomActif");
                }
            }
        }

        public string DescriptionActifVM
        {
            get
            {
                if (Actif.DescriptionActif != null)
                {
                    return Actif.DescriptionActif;
                }
                else
                {
                    return "description actif";
                }
            }

            set
            {
                if (Actif.DescriptionActif != value)
                {
                    Actif.DescriptionActif = value;
                    RaisePropertyChanged("DescriptionActif");
                }
            }
        }

        /// <summary>
        /// PASSIF
        /// </summary>

        public ObservableCollection<PassifModel> Passifs
        {
            get { return _passifs; }

            set { _passifs = value; }
        }

        public string NomPassifVM
        {
            get
            {
                if (Passif.NomPassif != null)
                {
                    return Passif.NomPassif;
                }
                else
                {
                    return "nom passif";
                }

            }

            set
            {
                if (Passif.NomPassif != value)
                {
                    Passif.NomPassif = value;
                    RaisePropertyChanged("NomPassif");
                }
            }
        }

        public string DescriptionPassifVM
        {
            get
            {
                if (Passif.DescriptionPassif != null)
                {
                    return Passif.DescriptionPassif;
                }
                else
                {
                    return "description passif";
                }
            }

            set
            {
                if (Passif.DescriptionPassif != value)
                {
                    Passif.DescriptionPassif = value;
                    RaisePropertyChanged("DescriptionPassif");
                }
            }
        }

        /// <summary>
        /// EQUIPEMENT
        /// </summary>

        public ObservableCollection<EquipementModel> Equipements
        {
            get { return _equipements; }

            set { _equipements = value; }
        }

        public string NomEquipementVM
        {
            get
            {
                if (Equipement.NomEquipement != null)
                {
                    return Equipement.NomEquipement;
                }
                else
                {
                    return "nom equipement";
                }

            }

            set
            {
                if (Equipement.NomEquipement != value)
                {
                    Equipement.NomEquipement = value;
                    RaisePropertyChanged("NomEquipement");
                }
            }
        }

        public string DescriptionEquipementVM
        {
            get
            {
                if (Equipement.DescriptionEquipement != null)
                {
                    return Equipement.DescriptionEquipement;
                }
                else
                {
                    return "description equipement";
                }
            }

            set
            {
                if (Passif.DescriptionPassif != value)
                {
                    Passif.DescriptionPassif = value;
                    RaisePropertyChanged("DescriptionEquipement");
                }
            }
        }




        #endregion

        #region ICommand


        /// <summary>
        /// NOTE
        /// </summary>

        void AddCreatedNoteExecute()
        {
            _notes.Add( Note = new NoteModel { NomNote = NomNoteVM, DescriptionNote = DescriptionNoteVM });   
        }


        bool CanAddCreatedNoteExecute()
        {
            return true;
        }


        public ICommand AddCreatedNote { get { return new RelayCommand(AddCreatedNoteExecute, CanAddCreatedNoteExecute); } }

        void CallAddSimpleNote()
        {
            AddSimpleNote addSimple = new AddSimpleNote(this);
            addSimple.ShowDialog();
        }

        bool CanCallAddSimpleNote() { return true; }


       public ICommand CallNote { get { return new RelayCommand(CallAddSimpleNote, CanCallAddSimpleNote); } }

        /// <summary>
        /// INVENTAIRE
        /// </summary>

        void AddCreatedInventaireExecute()
        {
            _inventaires.Add(Inventaire = new InventaireModel{ NomInventaire = NomInventaireVM, DescriptionInventaire = DescriptionInventaireVM });
        }

        bool CanAddCreatedInventaireExecute()
        {
            return true;
        }

        public ICommand AddCreatedInventaire { get { return new RelayCommand(AddCreatedInventaireExecute, CanAddCreatedInventaireExecute); } }

        void CallAddSimpleInventaire()
        {
            AddSimpleInventaire addSimple = new AddSimpleInventaire(this);
            addSimple.ShowDialog();
        }

        bool CanCallAddSimpleInventaire() { return true; }


        public ICommand CallInventaire { get { return new RelayCommand(CallAddSimpleInventaire, CanCallAddSimpleInventaire); } }


        /// <summary>
        /// ACTIF
        /// </summary>

        void AddCreatedActifExecute()
        {
            _actifs.Add(Actif = new ActifModel { NomActif = NomActifVM, DescriptionActif = DescriptionActifVM });
        }

        bool CanAddCreatedActifExecute()
        {
            return true;
        }

        public ICommand AddCreatedActif { get { return new RelayCommand(AddCreatedActifExecute, CanAddCreatedActifExecute); } }

        void CallAddSimpleActif()
        {
            AddSimpleActif addSimple = new AddSimpleActif(this);
            addSimple.ShowDialog();
        }

        bool CanCallAddSimpleActif() { return true; }

        public ICommand CallActif { get { return new RelayCommand(CallAddSimpleActif, CanCallAddSimpleActif); } }

        /// <summary>
        /// PASSIF
        /// </summary>
         
        void AddCreatedPassifExecute()
        {
            _passifs.Add(Passif = new PassifModel { NomPassif = NomPassifVM, DescriptionPassif = DescriptionPassifVM });
        }

        bool CanAddCreatedPassifExecute() 
        {
            return true;
        }

        public ICommand AddCreatedPassif { get { return new RelayCommand(AddCreatedPassifExecute, CanAddCreatedPassifExecute); } }

        void CallAddSimplePassif()
        {
            AddSimplePassif addSimple = new AddSimplePassif(this);
            addSimple.ShowDialog();
        }

        bool CanCallAddSimplePassif() { return true; }

        public ICommand CallPassif { get { return new RelayCommand(CallAddSimplePassif, CanCallAddSimplePassif); } }

        /// <summary>
        /// EQUIPEMENT
        /// </summary>

        void AddCreatedEquipementExecute()
        {
            _equipements.Add(Equipement = new EquipementModel { NomEquipement = NomEquipementVM, DescriptionEquipement = DescriptionEquipementVM });
        }

        bool CanAddCreatedEquipementExecute()
        {
            return true;
        }

        public ICommand AddCreatedEquipement { get { return new RelayCommand(AddCreatedEquipementExecute, CanAddCreatedEquipementExecute); } }

        void CallAddSimpleEquipement()
        {
            AddSimpleEquipement addSimple = new AddSimpleEquipement(this);
            addSimple.ShowDialog();
        }

        bool CanCallAddSimpleEquipement() { return true; }

        public ICommand CallEquipement { get { return new RelayCommand(CallAddSimpleEquipement, CanCallAddSimpleEquipement); } }

        public void SaveAllFiles(CreateViewModel vm)
        {
            string saveDataPath;
            saveDataPath = $"Character Sheet, {ProfileNameVM}{Environment.NewLine}";
            saveDataPath += $"{ Environment.NewLine}";

            //Profile
            saveDataPath += $"Profile:{ Environment.NewLine}";
            saveDataPath += $"Level: {vm.ProfileLevelVM}{ Environment.NewLine}";
            saveDataPath += $"Race: {vm.ProfileRaceVM}{ Environment.NewLine}";
            saveDataPath += $"Element: {vm.ProfileElementVM}{ Environment.NewLine}";
            saveDataPath += $"Classe: {vm.ProfileClasseVM}{ Environment.NewLine}";
            saveDataPath += $"Genre: {vm.ProfileGenreVM}{ Environment.NewLine}";
            saveDataPath += $"Age: {vm.ProfileAgeVM}{ Environment.NewLine}";
            saveDataPath += $"Taille: {vm.ProfileTailleVM}{ Environment.NewLine}";
            saveDataPath += $"Poids: {vm.ProfilePoidsVM}{ Environment.NewLine}";
            saveDataPath += $"Cheveux: {vm.ProfileCheveuxVM}{ Environment.NewLine}";
            saveDataPath += $"Peau: {vm.ProfilePeauVM}{ Environment.NewLine}";
            saveDataPath += $"Orientation: {vm.ProfileOrientationVM}{ Environment.NewLine}";
            saveDataPath += $"{Environment.NewLine}";

            //Statistique

            saveDataPath += $"Statistique:{Environment.NewLine}";
            saveDataPath += $"{Environment.NewLine}";
            saveDataPath += $"PV: {vm.StatistiquePVVM}{Environment.NewLine}";
            saveDataPath += $"Force: {vm.StatistiqueSTRVM}{Environment.NewLine}";
            saveDataPath += $"Intelligence: {vm.StatistiqueINTVM}{Environment.NewLine}";
            saveDataPath += $"Charisme: {vm.StatistiqueCHAVM}{Environment.NewLine}";
            saveDataPath += $"{Environment.NewLine}";
            //Equipement

            saveDataPath += $"Equipement:{Environment.NewLine}";
            saveDataPath += $"{Environment.NewLine}";
            for (int i=0; i< Equipements.Count; i++) 
            {
                saveDataPath += $"{Equipements[i].NomEquipement}: {Equipements[i].DescriptionEquipement}{Environment.NewLine}";
            }
            saveDataPath += $"{Environment.NewLine}";

            //Passif
            saveDataPath += $"Passif:{Environment.NewLine}";
            saveDataPath += $"{Environment.NewLine}";
            for (int i = 0; i < vm.Passifs.Count; i++)
            {
                saveDataPath += $"{vm.Passifs[i].NomPassif}: {vm.Passifs[i].DescriptionPassif}{Environment.NewLine}";
            }
            saveDataPath += $"{Environment.NewLine}";

            //Actif
            saveDataPath += $"Actif:{Environment.NewLine}";
            saveDataPath += $"{Environment.NewLine}";
            for (int i = 0; i < vm.Actifs.Count; i++)
            {
                saveDataPath += $"{vm.Actifs[i].NomActif}: {vm.Actifs[i].DescriptionActif}{Environment.NewLine}";
            }
            saveDataPath += $"{Environment.NewLine}";

            //Inventaire
            saveDataPath += $"Inventaire:{Environment.NewLine}";
            saveDataPath += $"{Environment.NewLine}";
            for (int i = 0; i < vm.Inventaires.Count; i++)
            {
                saveDataPath += $"{vm.Inventaires[i].NomInventaire}: {vm.Inventaires[i].DescriptionInventaire} {Environment.NewLine}";
            }
            saveDataPath += $"{Environment.NewLine}";

            //Note
            saveDataPath += $"Note:{Environment.NewLine}";
            saveDataPath += $"{Environment.NewLine}";
            for (int i = 0; i < vm.Notes.Count; i++)
            {
                saveDataPath += $"{vm.Notes[i].NomNote}: {vm.Notes[i].DescriptionNote} {Environment.NewLine}";
            }
            saveDataPath += $"{Environment.NewLine}";

            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Text file(*.txt)|*.txt";
            if(sfd.ShowDialog() == true)
            {
                File.WriteAllText(sfd.FileName, saveDataPath);
            }
        }

        

        #endregion
    }
}
