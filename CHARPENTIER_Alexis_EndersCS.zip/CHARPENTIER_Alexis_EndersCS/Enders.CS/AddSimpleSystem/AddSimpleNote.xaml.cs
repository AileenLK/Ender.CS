﻿using Enders.CS.Model;
using Enders.CS.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Enders.CS.AddSimpleSystem
{
    /// <summary>
    /// Logique d'interaction pour AddSimpleNote.xaml
    /// </summary>
    public partial class AddSimpleNote : Window
    {

        public CreateViewModel viewModel;
        public AddSimpleNote(CreateViewModel vm)
        {
            viewModel = vm;
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            NoteModel newNote = new NoteModel();
            newNote.NomNote = NameSend.Text;
            newNote.DescriptionNote = DescrSend.Text;
            viewModel.Notes.Add(newNote);
            this.Close();
        }

    }
}
